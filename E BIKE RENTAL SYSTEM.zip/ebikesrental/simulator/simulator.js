const { Web3 } = require('web3');
const contractABI = require('../backend/artifacts/contracts/EbikesRentalSystem.sol/EbikeRentalSystem.json').abi;
const contractAddress = '0x5FbDB2315678afecb367f032d93F642f64180aa3'; 
const web3 = new Web3('http://127.0.0.1:8545/'); 
const contract = new web3.eth.Contract(contractABI, contractAddress);

async function addBike(registrationNumber, rentPerHour, ownerAddress) {
    return contract.methods.addBike(registrationNumber, rentPerHour)
        .send({ from: ownerAddress, gas: 300000 });
}

async function rentBike(registrationNumber, customerAddress) {
    return contract.methods.rentBike(registrationNumber)
        .send({ from: customerAddress, gas: 300000 });
}

async function returnBike(registrationNumber, customerAddress) {
    return contract.methods.returnBike(registrationNumber)
        .send({ from: customerAddress, gas: 300000, value: 0 }); 
}

async function updateDuration(registrationNumber, customerAddress) {
    await contract.methods.updateDuration(registrationNumber)
        .send({ from: customerAddress, gas: 300000, value: 0 }); 
    return await contract.methods.bikes(registrationNumber).call();
}

async function getAllAvailableBikes() {
    return contract.methods.getAllAvailableBikes().call();
}

async function getAllBookedBikes() {
    return contract.methods.getAllBookedBikes().call();
}

async function getAllBikesByOwnerAddress(ownerAddress) {
    return contract.methods.getAllBikesByOwnerAddress(ownerAddress).call();
}

async function getAllBikes() {
    return contract.methods.getAllBikes().call();
}


function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
const simulator = async () => {
   

    while (true) {
        const bookedBikes = await getAllBookedBikes();
        for (let i = 0; i < bookedBikes.length; i++) {
            let bike = bookedBikes[i];
            bike = await updateDuration(bike.registrationNumber, bike.customer);
            console.log(bike);
            await wait(60000);
        }
    }
}

simulator();