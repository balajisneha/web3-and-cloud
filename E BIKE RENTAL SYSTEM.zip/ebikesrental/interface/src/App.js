import './App.css';
import HomePage from './screens/HomePage';
import Login from './screens/Login';
import AllRentalBikes from './screens/AllRentalBikes';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import OwnerDashboard from './screens/OwnerDashboard';
import AddBike from './screens/AddBike';


function App() {
  return (
    <>
    <Router>
      <Routes>
        <Route path='/' element={<HomePage/>}/>
        <Route path='/allrentalbikes' element={<AllRentalBikes/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/ownerdashboard' element={<OwnerDashboard/>}/>
        <Route path='/addbike' element={<AddBike/>}/>

      </Routes>
    </Router>
    
    </>
  );
}

export default App;
