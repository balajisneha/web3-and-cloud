const { Web3 } = require('web3');
const contractABI = require('./EbikeRentalSystem.json').abi;
const contractAddress = '0x5FbDB2315678afecb367f032d93F642f64180aa3';
const web3 = new Web3('http://127.0.0.1:8545/'); 
const contract = new web3.eth.Contract(contractABI, contractAddress);

// Add Bike
export async function addBike(registrationNumber, rentPerHour, ownerAddress) {
    return contract.methods.addBike(registrationNumber, rentPerHour)
        .send({ from: ownerAddress, gas: 300000 });
}

export async function checkBalance(address) {
    try {
        const balance = await web3.eth.getBalance(address);

        const balanceInEther = web3.utils.fromWei(balance, 'ether');

        console.log(`Balance of ${address}: ${balanceInEther} ETH`);
        return balance;
    } catch (error) {
        console.error("Error checking balance:", error);
        throw error;
    }
}


export async function isValidAddress(address) {
    return await web3.utils.isAddress(address);
}
// Rent Bike
export async function rentBike(registrationNumber, customerAddress) {
    return contract.methods.rentBike(registrationNumber)
        .send({ from: customerAddress, gas: 300000 });
}

// Return Bike
async function returnBike(registrationNumber, customerAddress) {
    return contract.methods.returnBike(registrationNumber)
        .send({ from: customerAddress, gas: 300000, value: 0 }); 
}

async function updateDuration(registrationNumber, customerAddress) {
    await contract.methods.updateDuration(registrationNumber)
        .send({ from: customerAddress, gas: 300000, value: 0 }); 
    return await contract.methods.bikes(registrationNumber).call();
}

export async function getAllAvailableBikes() {
    return contract.methods.getAllAvailableBikes().call();
}

async function getAllBookedBikes() {
    return contract.methods.getAllBookedBikes().call();
}

export async function getAllBikesByOwnerAddress(ownerAddress) {
    debugger;
    return contract.methods.getAllBikesByOwnerAddress(ownerAddress).call();
}

async function getAllBikes() {
    return contract.methods.getAllBikes().call();
}





