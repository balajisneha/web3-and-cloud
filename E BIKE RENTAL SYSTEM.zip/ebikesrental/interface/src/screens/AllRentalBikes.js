import React, { useState, useEffect } from 'react';
import { getAllAvailableBikes, rentBike } from '../blockChainMethods';

const AllRentalBikes = () => {
  const [userAddress, setAddress] = useState('');
  const [availableBikes, setAvailableBikes] = useState([]);

  useEffect(() => {
    const fetchBikes = async () => {
      try {
        const result = await getAllAvailableBikes();
        setAvailableBikes(result);
        console.log(result);
      } catch (error) {
        console.error('Error fetching e-bikes:', error);
      }
    };

    fetchBikes();
  }, []);

  const bookHandler = (registrationNumber) => {
    rentBike(registrationNumber, userAddress);
    alert('BOOKED');
  };

  const changeHandler = (e) => {
    setAddress(e.target.value);
  };

  return (
    <div className='grid container'>
      {availableBikes.map((bike) => (
        <div key={bike.registrationNumber} className='card'>
          <p>Registration Number: {bike.registrationNumber}</p>
          <p>Rent per Hour: {bike.rentPerHour.toString()} wei</p>
          <p>Owner Address: <span className='small'>{bike.owner}</span></p>
          <input
            type='text'
            autoComplete='off'
            name='text'
            className='input'
            placeholder='Enter User Address'
            onChange={changeHandler}
          />
          <div className='boxbtn'>  <button onClick={() => bookHandler(bike.registrationNumber)}>Book</button>
</div>
        </div>
      ))}
    </div>
  );
};

export default AllRentalBikes;
