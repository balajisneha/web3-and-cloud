import React from 'react'
import { Link } from 'react-router-dom'

const HomePage = () => {


    return (
        <>
            <div className='header1'>
                <h2>E-Bikes Rental System</h2>

            </div>
            <div className='flex'>
                <Link to='/allrentalbikes' className='none'>
                    <div class="card" >
                        <h2>Rent A Bike</h2>
                    </div>
                </Link>
                <Link to='/login' className='none'>
                    <div class="card">
                        <h2>Login</h2>
                    </div>
                </Link>

            </div>
        </>

    )
}

export default HomePage