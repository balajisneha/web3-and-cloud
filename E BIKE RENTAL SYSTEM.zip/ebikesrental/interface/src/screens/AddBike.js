import React, { useState } from 'react';
import { addBike } from '../blockChainMethods';

const AddBike = () => {
    const [ownerAddress, setOwnerAddress] = useState('');
    const [registrationNumber, setRegistrationNumber] = useState('');
    const [rentPerHour, setRentPerHour] = useState('');

    const addHandler = () => {
       
        addBike(registrationNumber,rentPerHour,ownerAddress);
        alert('added');
    }

    const handleRegistrationNumberChange = (e) => {
        setRegistrationNumber(e.target.value);
    };

    const handleRentPerHourChange = (e) => {
        setRentPerHour(e.target.value);
    };

    return (
        <><div className='header1'>
            <h2>Login </h2>

        </div><>
                <div className='flex container'>
                    <div className="custom-card">
                        <div className="custom-card-header">
                            <div className="custom-text-header">Add Bike</div>
                        </div>
                        <div className="custom-card-body">
                            <div>
                                <div className="custom-form-group">
                                    <label htmlFor="ownerAddress" className='white'>Owner Address:</label>
                                    <input
                                        required=""
                                        className="custom-form-control"
                                        type="text"
                                        id="ownerAddress"
                                        value={localStorage.getItem('ownerAddress')} />
                                </div>
                                <div className="custom-form-group">
                                    <label htmlFor="registrationNumber" className='white'>Registration Number:</label>
                                    <input
                                        required=""
                                        className="custom-form-control"
                                        type="text"
                                        id="registrationNumber"
                                        value={registrationNumber}
                                        onChange={handleRegistrationNumberChange} />
                                </div>
                                <div className="custom-form-group">
                                    <label htmlFor="rentPerHour" className='white'>Rent per Hour:</label>
                                    <input
                                        required=""
                                        className="custom-form-control"
                                        type="number"
                                        id="rentPerHour"
                                        value={rentPerHour}
                                        onChange={handleRentPerHourChange} />
                                </div>

                                <input type="submit" className="custom-btn" onClick={addHandler} />
                            </div>
                        </div>
                    </div>
                </div>
            </></>
    );
}

export default AddBike;
