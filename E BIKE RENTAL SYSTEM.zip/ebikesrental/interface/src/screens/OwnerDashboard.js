import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getAllBikesByOwnerAddress } from '../blockChainMethods';
import { checkBalance } from '../blockChainMethods';

const OwnerDashboard = () => {
    const [bikes, setBikes] = useState([]);
    const [balance, setBalance] = useState();

    useEffect(() => {
        const fetchBikes = async () => {
            try {
                const result = await getAllBikesByOwnerAddress(localStorage.getItem('ownerAddress'));
                const balance= await checkBalance(localStorage.getItem('ownerAddress'));
                setBikes(result);
                setBalance(balance);
            } catch (error) {
                console.error('Error fetching e-bikes:', error);
            }
        };

        fetchBikes();
    }, []);

    return (
        <>
            <div className='header'>
                <div className='chip'>Balance:{balance}</div>
                <Link to='/addbike'>
                    <button>Add E-Bike</button>
                </Link>
            </div>

            <div className='cards-div'>
                {bikes.map((bike) => (
                    <div className='card '>
                        <p>Registration Number: {bike.registrationNumber}</p>
                        <p>Rent per Hour: {bike.rentPerHour.toString()}wei</p>
                        {bike.isBooked && <p>Customer Address: {bike.customer}</p>}
                        <p className={`chip ${bike.isBooked && 'status'}`} > {bike.isBooked ? 'Booked' : 'Available'}</p>
                    </div>
                ))}
            </div>
        </>
    );
}

export default OwnerDashboard;
