import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { isValidAddress } from '../blockChainMethods';

const Login = () => {
    const navigate = useNavigate();
    const [address, setAddress] = useState('');

    const changeHandler = (e) => {
        setAddress(e.target.value);
    }

    const handleClick = async () => {
        const result = await isValidAddress(address);

        if (result) {
            localStorage.setItem('ownerAddress', address);
            navigate('/ownerdashboard');
        }
        else{
            alert('Invalid Address')
        }
    }

    return (
        <>
            <div className='header1'>
                <h2>Login </h2>
            </div>
            <div className='flex '>
                <div className="login-box">
                    <div>
                        <div className="user-box">
                            <input type="text" name="" required="" onChange={changeHandler} />
                            <label>Useraddress</label>
                        </div>
                        <center>
                            <button onClick={handleClick} disabled={address.length === 0}>
                                LOGIN
                                <span></span>
                            </button>
                        </center>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Login;
