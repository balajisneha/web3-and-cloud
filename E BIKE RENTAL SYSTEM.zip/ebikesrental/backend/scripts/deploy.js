async function main() {
    const [deployer] = await ethers.getSigners();
    const EbikeRentalSystem = await ethers.getContractFactory("EbikeRentalSystem");
    const contract = await EbikeRentalSystem.deploy();
    console.log("EbikeRentalSystem deployed to:", contract.target);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
